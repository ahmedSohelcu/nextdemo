exports.id = 175;
exports.ids = [175];
exports.modules = {

/***/ 9175:
/***/ (function(__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1664);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5675);






const SingleProduct = () => {
  // export default function SingleBlog(){
  return /*#__PURE__*/_jsxs("div", {
    className: styles.single_blog,
    children: [/*#__PURE__*/_jsx("h4", {
      className: styles.blog_title,
      children: "Product title"
    }), /*#__PURE__*/_jsx(Image, {
      src: "/download (1).jpg",
      width: 550,
      height: 350,
      alt: "fsdsaf"
    }), /*#__PURE__*/_jsxs("div", {
      className: styles.blog_content,
      children: ["prodcut content goose here.prodcut content goose here.prodcut content goose here. .prodcut content goose here.", /*#__PURE__*/_jsx("br", {})]
    }), /*#__PURE__*/_jsxs("div", {
      children: [/*#__PURE__*/_jsx(Link, {
        href: "/shop/5",
        className: styles.shop_continue_button,
        children: "Add to cart"
      }), /*#__PURE__*/_jsx(Link, {
        className: styles.shop_continue_button,
        href: "/shop/5",
        children: "10tk"
      }), /*#__PURE__*/_jsx(Link, {
        className: styles.shop_continue_button,
        href: "/shop/5",
        children: "details"
      })]
    })]
  });
};

/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (SingleProduct)));

/***/ })

};
;