exports.id = "components_Layout_js-components_SingleProduct_js";
exports.ids = ["components_Layout_js-components_SingleProduct_js"];
exports.modules = {

/***/ "./components/Layout.js":
/*!******************************!*\
  !*** ./components/Layout.js ***!
  \******************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _styles_blog_module_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../styles/blog.module.css */ "./styles/blog.module.css");
/* harmony import */ var _styles_blog_module_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_styles_blog_module_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/image */ "./node_modules/next/image.js");
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);

var _jsxFileName = "D:\\next_project\\next_practice\\components\\Layout.js";




const Layout = ({
  children
}) => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("header", {
      className: (_styles_blog_module_css__WEBPACK_IMPORTED_MODULE_3___default().header),
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("br", {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 9,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
        src: "/vercel.svg",
        alt: "Vercel Logo",
        width: 100,
        height: 50
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 10,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("ul", {
        className: (_styles_blog_module_css__WEBPACK_IMPORTED_MODULE_3___default().menu),
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("li", {
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
            href: "/home",
            children: "Home"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 16,
            columnNumber: 13
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 15,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("li", {
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
            href: "/about",
            children: "About Us"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 19,
            columnNumber: 13
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 18,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("li", {
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
            href: "/contactus",
            children: "Contact Us"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 22,
            columnNumber: 13
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 21,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("li", {
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
            href: "/shop",
            children: "Shop"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 25,
            columnNumber: 13
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 24,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("li", {
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
            href: "/blog",
            children: "Blog"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 28,
            columnNumber: 13
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 27,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("li", {
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
            href: "/gallery",
            children: "Gallery"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 31,
            columnNumber: 13
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 30,
          columnNumber: 11
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 14,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 8,
      columnNumber: 7
    }, undefined), children, /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("footer", {
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("h2", {
        children: "Footer From layout page "
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 37,
        columnNumber: 7
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 36,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 7,
    columnNumber: 5
  }, undefined);
};

/* harmony default export */ __webpack_exports__["default"] = (Layout);

/***/ }),

/***/ "./components/SingleProduct.js":
/*!*************************************!*\
  !*** ./components/SingleProduct.js ***!
  \*************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styles_blog_module_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../styles/blog.module.css */ "./styles/blog.module.css");
/* harmony import */ var _styles_blog_module_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_styles_blog_module_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/image */ "./node_modules/next/image.js");
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);

var _jsxFileName = "D:\\next_project\\next_practice\\components\\SingleProduct.js";




const SingleProduct = () => {
  // export default function SingleBlog(){
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
    className: (_styles_blog_module_css__WEBPACK_IMPORTED_MODULE_3___default().single_blog),
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("h4", {
      className: (_styles_blog_module_css__WEBPACK_IMPORTED_MODULE_3___default().blog_title),
      children: "Product title"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 9,
      columnNumber: 7
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
      src: "/download (1).jpg",
      width: 550,
      height: 350,
      alt: "fsdsaf"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 13,
      columnNumber: 7
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
      className: (_styles_blog_module_css__WEBPACK_IMPORTED_MODULE_3___default().blog_content),
      children: ["prodcut content goose here.prodcut content goose here.prodcut content goose here. .prodcut content goose here.", /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("br", {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 17,
        columnNumber: 7
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 14,
      columnNumber: 7
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
        href: "/shop/5",
        className: (_styles_blog_module_css__WEBPACK_IMPORTED_MODULE_3___default().shop_continue_button),
        children: "Add to cart"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 20,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
        className: (_styles_blog_module_css__WEBPACK_IMPORTED_MODULE_3___default().shop_continue_button),
        href: "/shop/5",
        children: "10tk"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 21,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
        className: (_styles_blog_module_css__WEBPACK_IMPORTED_MODULE_3___default().shop_continue_button),
        href: "/shop/5",
        children: "details"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 22,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 19,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 8,
    columnNumber: 5
  }, undefined);
};

/* harmony default export */ __webpack_exports__["default"] = (SingleProduct);

/***/ }),

/***/ "./styles/blog.module.css":
/*!********************************!*\
  !*** ./styles/blog.module.css ***!
  \********************************/
/***/ (function(module) {

// Exports
module.exports = {
	"container": "blog_container__1ntJ1",
	"title": "blog_title__3VvZ3",
	"single_blog": "blog_single_blog__122se",
	"blog_title": "blog_blog_title__3cZ3u",
	"shop_continue_button": "blog_shop_continue_button__1NIpF",
	"blog_continue_button": "blog_blog_continue_button__sO4_9",
	"right": "blog_right__25M9X",
	"left": "blog_left__2ma1s",
	"menu": "blog_menu__2qM-4",
	"buttonArea": "blog_buttonArea__2ThKv",
	"addToCart": "blog_addToCart__1rIWj",
	"productDetailsButton": "blog_productDetailsButton__2keA3",
	"headerCartIcon": "blog_headerCartIcon__3xYbS",
	"header": "blog_header__dEcns"
};


/***/ }),

/***/ "?ca47":
/*!******************************************!*\
  !*** ./utils/resolve-rewrites (ignored) ***!
  \******************************************/
/***/ (function() {

/* (ignored) */

/***/ })

};
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9uZXh0X3ByYWN0aWNlLy4vY29tcG9uZW50cy9MYXlvdXQuanMiLCJ3ZWJwYWNrOi8vbmV4dF9wcmFjdGljZS8uL2NvbXBvbmVudHMvU2luZ2xlUHJvZHVjdC5qcyIsIndlYnBhY2s6Ly9uZXh0X3ByYWN0aWNlLy4vc3R5bGVzL2Jsb2cubW9kdWxlLmNzcyIsIndlYnBhY2s6Ly9uZXh0X3ByYWN0aWNlL2lnbm9yZWR8RDpcXG5leHRfcHJvamVjdFxcbmV4dF9wcmFjdGljZVxcbm9kZV9tb2R1bGVzXFxuZXh0XFxkaXN0XFxuZXh0LXNlcnZlclxcbGliXFxyb3V0ZXJ8Li91dGlscy9yZXNvbHZlLXJld3JpdGVzIl0sIm5hbWVzIjpbIkxheW91dCIsImNoaWxkcmVuIiwic3R5bGVzIiwiU2luZ2xlUHJvZHVjdCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTs7QUFFQSxNQUFNQSxNQUFNLEdBQUcsQ0FBQztBQUFDQztBQUFELENBQUQsS0FBYztBQUMzQixzQkFDRTtBQUFBLDRCQUNFO0FBQVEsZUFBUyxFQUFFQyx1RUFBbkI7QUFBQSw4QkFDRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQURGLGVBRUUsOERBQUMsbURBQUQ7QUFBTyxXQUFHLEVBQUMsYUFBWDtBQUF5QixXQUFHLEVBQUUsYUFBOUI7QUFBNEMsYUFBSyxFQUFLLEdBQXREO0FBQTRELGNBQU0sRUFBSztBQUF2RTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUZGLGVBTUU7QUFBSSxpQkFBUyxFQUFFQSxxRUFBZjtBQUFBLGdDQUNFO0FBQUEsaUNBQ0UsOERBQUMsa0RBQUQ7QUFBTSxnQkFBSSxFQUFDLE9BQVg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQURGLGVBSUU7QUFBQSxpQ0FDRSw4REFBQyxrREFBRDtBQUFNLGdCQUFJLEVBQUMsUUFBWDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBSkYsZUFPRTtBQUFBLGlDQUNFLDhEQUFDLGtEQUFEO0FBQU0sZ0JBQUksRUFBQyxZQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFQRixlQVVFO0FBQUEsaUNBQ0UsOERBQUMsa0RBQUQ7QUFBTSxnQkFBSSxFQUFDLE9BQVg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVZGLGVBYUU7QUFBQSxpQ0FDRSw4REFBQyxrREFBRDtBQUFNLGdCQUFJLEVBQUMsT0FBWDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBYkYsZUFnQkU7QUFBQSxpQ0FDRSw4REFBQyxrREFBRDtBQUFNLGdCQUFJLEVBQUMsVUFBWDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFORjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBREYsRUE0QktELFFBNUJMLGVBNkJFO0FBQUEsNkJBQ0E7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFEQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTdCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFERjtBQW1DRCxDQXBDRDs7QUFzQ0EsK0RBQWVELE1BQWYsRTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzFDQTtBQUNBO0FBQ0E7O0FBRUEsTUFBTUcsYUFBYSxHQUFHLE1BQU07QUFDNUI7QUFDRSxzQkFDRTtBQUFLLGFBQVMsRUFBS0QsNEVBQW5CO0FBQUEsNEJBQ0U7QUFBSSxlQUFTLEVBQUtBLDJFQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFERixlQUtFLDhEQUFDLG1EQUFEO0FBQU8sU0FBRyxFQUFDLG1CQUFYO0FBQStCLFdBQUssRUFBRSxHQUF0QztBQUEyQyxZQUFNLEVBQUUsR0FBbkQ7QUFBd0QsU0FBRyxFQUFDO0FBQTVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBTEYsZUFNRTtBQUFLLGVBQVMsRUFBS0EsNkVBQW5CO0FBQUEsZ0pBR0E7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFIQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBTkYsZUFXRTtBQUFBLDhCQUNFLDhEQUFDLGtEQUFEO0FBQU0sWUFBSSxFQUFDLFNBQVg7QUFBcUIsaUJBQVMsRUFBR0EscUZBQWpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQURGLGVBRUUsOERBQUMsa0RBQUQ7QUFBTSxpQkFBUyxFQUFHQSxxRkFBbEI7QUFBK0MsWUFBSSxFQUFDLFNBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUZGLGVBR0UsOERBQUMsa0RBQUQ7QUFBTSxpQkFBUyxFQUFHQSxxRkFBbEI7QUFBZ0QsWUFBSSxFQUFDLFNBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFYRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFERjtBQXFCRCxDQXZCRDs7QUF5QkEsK0RBQWVDLGFBQWYsRTs7Ozs7Ozs7OztBQzdCQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7OztBQ2hCQSxlIiwiZmlsZSI6ImNvbXBvbmVudHNfTGF5b3V0X2pzLWNvbXBvbmVudHNfU2luZ2xlUHJvZHVjdF9qcy5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBMaW5rIGZyb20gJ25leHQvbGluaydcclxuaW1wb3J0IHN0eWxlcyBmcm9tIFwiLi4vc3R5bGVzL2Jsb2cubW9kdWxlLmNzc1wiO1xyXG5pbXBvcnQgSW1hZ2UgZnJvbSAnbmV4dC9pbWFnZSdcclxuXHJcbmNvbnN0IExheW91dCA9ICh7Y2hpbGRyZW59KT0+e1xyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2PlxyXG4gICAgICA8aGVhZGVyIGNsYXNzTmFtZT17c3R5bGVzLmhlYWRlcn0+XHJcbiAgICAgICAgPGJyLz5cclxuICAgICAgICA8SW1hZ2Ugc3JjPVwiL3ZlcmNlbC5zdmdcIiBhbHQgPVwiVmVyY2VsIExvZ29cIiB3aWR0aCA9IHsgMTAwIH0gaGVpZ2h0ID0geyA1MCB9Lz4gIFxyXG4gICAgICAgIHsvKiA8ZGl2IGNsYXNzTmFtZT17c3R5bGVzLmhlYWRlckNhcnRJY29ufT5cclxuICAgICAgICAgIDVcclxuICAgICAgICA8L2Rpdj4gICAqL31cclxuICAgICAgICA8dWwgY2xhc3NOYW1lPXtzdHlsZXMubWVudX0+ICAgICAgICAgICAgXHJcbiAgICAgICAgICA8bGk+XHJcbiAgICAgICAgICAgIDxMaW5rIGhyZWY9XCIvaG9tZVwiPkhvbWU8L0xpbms+XHJcbiAgICAgICAgICA8L2xpPlxyXG4gICAgICAgICAgPGxpPlxyXG4gICAgICAgICAgICA8TGluayBocmVmPVwiL2Fib3V0XCI+QWJvdXQgVXM8L0xpbms+XHJcbiAgICAgICAgICA8L2xpPlxyXG4gICAgICAgICAgPGxpPlxyXG4gICAgICAgICAgICA8TGluayBocmVmPVwiL2NvbnRhY3R1c1wiPkNvbnRhY3QgVXM8L0xpbms+XHJcbiAgICAgICAgICA8L2xpPlxyXG4gICAgICAgICAgPGxpPlxyXG4gICAgICAgICAgICA8TGluayBocmVmPVwiL3Nob3BcIj5TaG9wPC9MaW5rPlxyXG4gICAgICAgICAgPC9saT5cclxuICAgICAgICAgIDxsaT5cclxuICAgICAgICAgICAgPExpbmsgaHJlZj1cIi9ibG9nXCI+QmxvZzwvTGluaz5cclxuICAgICAgICAgIDwvbGk+XHJcbiAgICAgICAgICA8bGk+XHJcbiAgICAgICAgICAgIDxMaW5rIGhyZWY9XCIvZ2FsbGVyeVwiPkdhbGxlcnk8L0xpbms+XHJcbiAgICAgICAgICA8L2xpPlxyXG4gICAgICAgIDwvdWw+XHJcbiAgICAgIDwvaGVhZGVyPlxyXG4gICAgICAgIHtjaGlsZHJlbn1cclxuICAgICAgPGZvb3Rlcj5cclxuICAgICAgPGgyPkZvb3RlciBGcm9tIGxheW91dCBwYWdlIDwvaDI+XHJcbiAgICAgIDwvZm9vdGVyPlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgTGF5b3V0OyIsImltcG9ydCBzdHlsZXMgZnJvbSBcIi4uL3N0eWxlcy9ibG9nLm1vZHVsZS5jc3NcIjtcclxuaW1wb3J0IExpbmsgZnJvbSAnbmV4dC9saW5rJ1xyXG5pbXBvcnQgSW1hZ2UgZnJvbSAnbmV4dC9pbWFnZSdcclxuXHJcbmNvbnN0IFNpbmdsZVByb2R1Y3QgPSAoKSA9PiB7XHJcbi8vIGV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFNpbmdsZUJsb2coKXtcclxuICByZXR1cm4oXHJcbiAgICA8ZGl2IGNsYXNzTmFtZSA9IHsgc3R5bGVzLnNpbmdsZV9ibG9nIH0+XHJcbiAgICAgIDxoNCBjbGFzc05hbWUgPSB7IHN0eWxlcy5ibG9nX3RpdGxlIH0+XHJcbiAgICAgICBQcm9kdWN0IHRpdGxlXHJcbiAgICAgIDwvaDQ+XHJcbiAgICAgIFxyXG4gICAgICA8SW1hZ2Ugc3JjPVwiL2Rvd25sb2FkICgxKS5qcGdcIiB3aWR0aD17NTUwfSBoZWlnaHQ9ezM1MH0gYWx0PVwiZnNkc2FmXCIgLz5cclxuICAgICAgPGRpdiBjbGFzc05hbWUgPSB7IHN0eWxlcy5ibG9nX2NvbnRlbnQgfT5cclxuICAgICAgcHJvZGN1dCBjb250ZW50IGdvb3NlIGhlcmUucHJvZGN1dCBjb250ZW50IGdvb3NlIGhlcmUucHJvZGN1dCBjb250ZW50IGdvb3NlIGhlcmUuXHJcbiAgICAgIC5wcm9kY3V0IGNvbnRlbnQgZ29vc2UgaGVyZS5cclxuICAgICAgPGJyLz5cclxuICAgICAgPC9kaXY+XHJcbiAgICAgIDxkaXY+XHJcbiAgICAgICAgPExpbmsgaHJlZj1cIi9zaG9wLzVcIiBjbGFzc05hbWUgPXtzdHlsZXMuc2hvcF9jb250aW51ZV9idXR0b259PkFkZCB0byBjYXJ0PC9MaW5rPlxyXG4gICAgICAgIDxMaW5rIGNsYXNzTmFtZSA9e3N0eWxlcy5zaG9wX2NvbnRpbnVlX2J1dHRvbn0gaHJlZj1cIi9zaG9wLzVcIj4xMHRrPC9MaW5rPlxyXG4gICAgICAgIDxMaW5rIGNsYXNzTmFtZSA9e3N0eWxlcy5zaG9wX2NvbnRpbnVlX2J1dHRvbiB9IGhyZWY9XCIvc2hvcC81XCI+XHJcbiAgICAgICAgICBkZXRhaWxzXHJcbiAgICAgICAgPC9MaW5rPlxyXG4gICAgICA8L2Rpdj4gXHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBTaW5nbGVQcm9kdWN0O1xyXG5cclxuIiwiLy8gRXhwb3J0c1xubW9kdWxlLmV4cG9ydHMgPSB7XG5cdFwiY29udGFpbmVyXCI6IFwiYmxvZ19jb250YWluZXJfXzFudEoxXCIsXG5cdFwidGl0bGVcIjogXCJibG9nX3RpdGxlX18zVnZaM1wiLFxuXHRcInNpbmdsZV9ibG9nXCI6IFwiYmxvZ19zaW5nbGVfYmxvZ19fMTIyc2VcIixcblx0XCJibG9nX3RpdGxlXCI6IFwiYmxvZ19ibG9nX3RpdGxlX18zY1ozdVwiLFxuXHRcInNob3BfY29udGludWVfYnV0dG9uXCI6IFwiYmxvZ19zaG9wX2NvbnRpbnVlX2J1dHRvbl9fMU5JcEZcIixcblx0XCJibG9nX2NvbnRpbnVlX2J1dHRvblwiOiBcImJsb2dfYmxvZ19jb250aW51ZV9idXR0b25fX3NPNF85XCIsXG5cdFwicmlnaHRcIjogXCJibG9nX3JpZ2h0X18yNU05WFwiLFxuXHRcImxlZnRcIjogXCJibG9nX2xlZnRfXzJtYTFzXCIsXG5cdFwibWVudVwiOiBcImJsb2dfbWVudV9fMnFNLTRcIixcblx0XCJidXR0b25BcmVhXCI6IFwiYmxvZ19idXR0b25BcmVhX18yVGhLdlwiLFxuXHRcImFkZFRvQ2FydFwiOiBcImJsb2dfYWRkVG9DYXJ0X18xcklXalwiLFxuXHRcInByb2R1Y3REZXRhaWxzQnV0dG9uXCI6IFwiYmxvZ19wcm9kdWN0RGV0YWlsc0J1dHRvbl9fMmtlQTNcIixcblx0XCJoZWFkZXJDYXJ0SWNvblwiOiBcImJsb2dfaGVhZGVyQ2FydEljb25fXzN4WWJTXCIsXG5cdFwiaGVhZGVyXCI6IFwiYmxvZ19oZWFkZXJfX2RFY25zXCJcbn07XG4iLCIvKiAoaWdub3JlZCkgKi8iXSwic291cmNlUm9vdCI6IiJ9