exports.id = "components_SingleProduct_js";
exports.ids = ["components_SingleProduct_js"];
exports.modules = {

/***/ "./components/SingleProduct.js":
/*!*************************************!*\
  !*** ./components/SingleProduct.js ***!
  \*************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styles_blog_module_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../styles/blog.module.css */ "./styles/blog.module.css");
/* harmony import */ var _styles_blog_module_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_styles_blog_module_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/image */ "./node_modules/next/image.js");
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);

var _jsxFileName = "D:\\next_project\\next_practice\\components\\SingleProduct.js";




const SingleProduct = () => {
  // export default function SingleBlog(){
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
    className: (_styles_blog_module_css__WEBPACK_IMPORTED_MODULE_3___default().single_blog),
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("h4", {
      className: (_styles_blog_module_css__WEBPACK_IMPORTED_MODULE_3___default().blog_title),
      children: "Product title"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 9,
      columnNumber: 7
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
      src: "/download (1).jpg",
      width: 550,
      height: 350,
      alt: "fsdsaf"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 13,
      columnNumber: 7
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
      className: (_styles_blog_module_css__WEBPACK_IMPORTED_MODULE_3___default().blog_content),
      children: ["prodcut content goose here.prodcut content goose here.prodcut content goose here. .prodcut content goose here.", /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("br", {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 17,
        columnNumber: 7
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 14,
      columnNumber: 7
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
        href: "/shop/5",
        className: (_styles_blog_module_css__WEBPACK_IMPORTED_MODULE_3___default().shop_continue_button),
        children: "Add to cart"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 20,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
        className: (_styles_blog_module_css__WEBPACK_IMPORTED_MODULE_3___default().shop_continue_button),
        href: "/shop/5",
        children: "10tk"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 21,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
        className: (_styles_blog_module_css__WEBPACK_IMPORTED_MODULE_3___default().shop_continue_button),
        href: "/shop/5",
        children: "details"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 22,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 19,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 8,
    columnNumber: 5
  }, undefined);
};

/* harmony default export */ __webpack_exports__["default"] = (SingleProduct);

/***/ })

};
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9uZXh0X3ByYWN0aWNlLy4vY29tcG9uZW50cy9TaW5nbGVQcm9kdWN0LmpzIl0sIm5hbWVzIjpbIlNpbmdsZVByb2R1Y3QiLCJzdHlsZXMiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7O0FBRUEsTUFBTUEsYUFBYSxHQUFHLE1BQU07QUFDNUI7QUFDRSxzQkFDRTtBQUFLLGFBQVMsRUFBS0MsNEVBQW5CO0FBQUEsNEJBQ0U7QUFBSSxlQUFTLEVBQUtBLDJFQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFERixlQUtFLDhEQUFDLG1EQUFEO0FBQU8sU0FBRyxFQUFDLG1CQUFYO0FBQStCLFdBQUssRUFBRSxHQUF0QztBQUEyQyxZQUFNLEVBQUUsR0FBbkQ7QUFBd0QsU0FBRyxFQUFDO0FBQTVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBTEYsZUFNRTtBQUFLLGVBQVMsRUFBS0EsNkVBQW5CO0FBQUEsZ0pBR0E7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFIQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBTkYsZUFXRTtBQUFBLDhCQUNFLDhEQUFDLGtEQUFEO0FBQU0sWUFBSSxFQUFDLFNBQVg7QUFBcUIsaUJBQVMsRUFBR0EscUZBQWpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQURGLGVBRUUsOERBQUMsa0RBQUQ7QUFBTSxpQkFBUyxFQUFHQSxxRkFBbEI7QUFBK0MsWUFBSSxFQUFDLFNBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUZGLGVBR0UsOERBQUMsa0RBQUQ7QUFBTSxpQkFBUyxFQUFHQSxxRkFBbEI7QUFBZ0QsWUFBSSxFQUFDLFNBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFYRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFERjtBQXFCRCxDQXZCRDs7QUF5QkEsK0RBQWVELGFBQWYsRSIsImZpbGUiOiJjb21wb25lbnRzX1NpbmdsZVByb2R1Y3RfanMuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgc3R5bGVzIGZyb20gXCIuLi9zdHlsZXMvYmxvZy5tb2R1bGUuY3NzXCI7XHJcbmltcG9ydCBMaW5rIGZyb20gJ25leHQvbGluaydcclxuaW1wb3J0IEltYWdlIGZyb20gJ25leHQvaW1hZ2UnXHJcblxyXG5jb25zdCBTaW5nbGVQcm9kdWN0ID0gKCkgPT4ge1xyXG4vLyBleHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBTaW5nbGVCbG9nKCl7XHJcbiAgcmV0dXJuKFxyXG4gICAgPGRpdiBjbGFzc05hbWUgPSB7IHN0eWxlcy5zaW5nbGVfYmxvZyB9PlxyXG4gICAgICA8aDQgY2xhc3NOYW1lID0geyBzdHlsZXMuYmxvZ190aXRsZSB9PlxyXG4gICAgICAgUHJvZHVjdCB0aXRsZVxyXG4gICAgICA8L2g0PlxyXG4gICAgICBcclxuICAgICAgPEltYWdlIHNyYz1cIi9kb3dubG9hZCAoMSkuanBnXCIgd2lkdGg9ezU1MH0gaGVpZ2h0PXszNTB9IGFsdD1cImZzZHNhZlwiIC8+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lID0geyBzdHlsZXMuYmxvZ19jb250ZW50IH0+XHJcbiAgICAgIHByb2RjdXQgY29udGVudCBnb29zZSBoZXJlLnByb2RjdXQgY29udGVudCBnb29zZSBoZXJlLnByb2RjdXQgY29udGVudCBnb29zZSBoZXJlLlxyXG4gICAgICAucHJvZGN1dCBjb250ZW50IGdvb3NlIGhlcmUuXHJcbiAgICAgIDxici8+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgICA8ZGl2PlxyXG4gICAgICAgIDxMaW5rIGhyZWY9XCIvc2hvcC81XCIgY2xhc3NOYW1lID17c3R5bGVzLnNob3BfY29udGludWVfYnV0dG9ufT5BZGQgdG8gY2FydDwvTGluaz5cclxuICAgICAgICA8TGluayBjbGFzc05hbWUgPXtzdHlsZXMuc2hvcF9jb250aW51ZV9idXR0b259IGhyZWY9XCIvc2hvcC81XCI+MTB0azwvTGluaz5cclxuICAgICAgICA8TGluayBjbGFzc05hbWUgPXtzdHlsZXMuc2hvcF9jb250aW51ZV9idXR0b24gfSBocmVmPVwiL3Nob3AvNVwiPlxyXG4gICAgICAgICAgZGV0YWlsc1xyXG4gICAgICAgIDwvTGluaz5cclxuICAgICAgPC9kaXY+IFxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgU2luZ2xlUHJvZHVjdDtcclxuXHJcbiJdLCJzb3VyY2VSb290IjoiIn0=