(function() {
var exports = {};
exports.id = 800;
exports.ids = [800];
exports.modules = {

/***/ 6150:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "getStaticProps": function() { return /* binding */ getStaticProps; }
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _styles_blog_module_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2454);
/* harmony import */ var _styles_blog_module_css__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_styles_blog_module_css__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _components_SingleProduct__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9175);
/* harmony import */ var _components_Layout__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7428);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5675);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1664);










const Shop = props => {
  var _props$data$products$;

  // const hello = function(e){
  //   e.preventDefault();
  //   alert('hello...');
  // }
  const productsComponent = (_props$data$products$ = props.data.products.random_products) === null || _props$data$products$ === void 0 ? void 0 : _props$data$products$.map((product, index) => /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
    className: (_styles_blog_module_css__WEBPACK_IMPORTED_MODULE_6___default().single_blog),
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
      className: (_styles_blog_module_css__WEBPACK_IMPORTED_MODULE_6___default().blog_title),
      children: product.name
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_image__WEBPACK_IMPORTED_MODULE_4__.default, {
      src: "http:" + product.photo,
      width: 550,
      height: 350
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
      className: (_styles_blog_module_css__WEBPACK_IMPORTED_MODULE_6___default().buttonArea),
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
        className: (_styles_blog_module_css__WEBPACK_IMPORTED_MODULE_6___default().addToCart),
        onClick: () => hello(),
        href: "/shop/5",
        className: (_styles_blog_module_css__WEBPACK_IMPORTED_MODULE_6___default().shop_continue_button),
        children: "Add to cart"
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
        className: (_styles_blog_module_css__WEBPACK_IMPORTED_MODULE_6___default().productDetailsButton),
        className: (_styles_blog_module_css__WEBPACK_IMPORTED_MODULE_6___default().shop_continue_button),
        href: "/shop/5",
        children: "Product details"
      })]
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("style", {
      children: `
    .blog_single_blog__122se {
      width: 223px;
      display: inline-block;
      border: 1px solid #ddd;
      padding: 10px;
      margin: 5px;
      border-radius: 5px;
      line-height: 25px;
    }
    .blog_buttonArea__2ThKv a {
      margin: 1px 5px;
    }
    
    `
    })]
  }, "{product.id}"));
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react__WEBPACK_IMPORTED_MODULE_1__.Fragment, {
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_Layout__WEBPACK_IMPORTED_MODULE_3__/* .default */ .Z, {
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
        className: (_styles_blog_module_css__WEBPACK_IMPORTED_MODULE_6___default().title),
        children: " Hello form Shop page.. "
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: (_styles_blog_module_css__WEBPACK_IMPORTED_MODULE_6___default().container),
        children: productsComponent
      })]
    })
  });
}; //============================================
//getServerSideProps
//============================================
// export async function //getServerSideProps(){


async function getStaticProps() {
  const res = await fetch('https://demostore.uparzon.com/api/uparzonweb/get_home_products');
  const data = await res.json();
  return {
    props: {
      data
    },
    revalidate: 10 // In seconds  

  };
}
/* harmony default export */ __webpack_exports__["default"] = (Shop);

/***/ }),

/***/ 5273:
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/lib/head.js");;

/***/ }),

/***/ 8417:
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/lib/router-context.js");;

/***/ }),

/***/ 2238:
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/lib/router/utils/get-asset-path-from-route.js");;

/***/ }),

/***/ 5519:
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/lib/to-base-64.js");;

/***/ }),

/***/ 444:
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/server/image-config.js");;

/***/ }),

/***/ 9297:
/***/ (function(module) {

"use strict";
module.exports = require("react");;

/***/ }),

/***/ 5282:
/***/ (function(module) {

"use strict";
module.exports = require("react/jsx-runtime");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = function(moduleId) { return __webpack_require__(__webpack_require__.s = moduleId); }
var __webpack_exports__ = __webpack_require__.X(0, [297,61,422,175], function() { return __webpack_exec__(6150); });
module.exports = __webpack_exports__;

})();