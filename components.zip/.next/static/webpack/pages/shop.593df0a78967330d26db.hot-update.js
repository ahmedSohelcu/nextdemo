self["webpackHotUpdate_N_E"]("pages/shop",{

/***/ "./pages/shop/index.js":
/*!*****************************!*\
  !*** ./pages/shop/index.js ***!
  \*****************************/
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "__N_SSP": function() { return /* binding */ __N_SSP; }
/* harmony export */ });
/* harmony import */ var D_next_project_next_practice_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _styles_blog_module_css__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../styles/blog.module.css */ "./styles/blog.module.css");
/* harmony import */ var _styles_blog_module_css__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_styles_blog_module_css__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _components_SingleProduct__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../components/SingleProduct */ "./components/SingleProduct.js");
/* harmony import */ var _components_Layout__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../components/Layout */ "./components/Layout.js");
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! next/image */ "./node_modules/next/image.js");
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_6__);
/* module decorator */ module = __webpack_require__.hmd(module);



var _jsxFileName = "D:\\next_project\\next_practice\\pages\\shop\\index.js",
    _this = undefined;









var Shop = function Shop(props) {
  var _props$data$products$;

  // const hello = function(e){
  //   e.preventDefault();
  //   alert('hello...');
  // }
  var productsComponent = (_props$data$products$ = props.data.products.random_products) === null || _props$data$products$ === void 0 ? void 0 : _props$data$products$.map(function (product, index) {
    var _jsxDEV2, _jsxDEV3;

    return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
      className: (_styles_blog_module_css__WEBPACK_IMPORTED_MODULE_7___default().single_blog),
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("h4", {
        className: (_styles_blog_module_css__WEBPACK_IMPORTED_MODULE_7___default().blog_title),
        children: product.name
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 19,
        columnNumber: 5
      }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)((next_image__WEBPACK_IMPORTED_MODULE_5___default()), {
        src: "http:" + product.photo,
        width: 550,
        height: 350
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 23,
        columnNumber: 5
      }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
        className: (_styles_blog_module_css__WEBPACK_IMPORTED_MODULE_7___default().buttonArea),
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("a", (_jsxDEV2 = {
          className: (_styles_blog_module_css__WEBPACK_IMPORTED_MODULE_7___default().addToCart),
          onClick: function onClick() {
            return hello();
          },
          href: "/shop/5"
        }, (0,D_next_project_next_practice_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_0__.default)(_jsxDEV2, "className", (_styles_blog_module_css__WEBPACK_IMPORTED_MODULE_7___default().shop_continue_button)), (0,D_next_project_next_practice_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_0__.default)(_jsxDEV2, "children", "Add to cart"), _jsxDEV2), void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 26,
          columnNumber: 7
        }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("a", (_jsxDEV3 = {
          className: (_styles_blog_module_css__WEBPACK_IMPORTED_MODULE_7___default().productDetailsButton)
        }, (0,D_next_project_next_practice_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_0__.default)(_jsxDEV3, "className", (_styles_blog_module_css__WEBPACK_IMPORTED_MODULE_7___default().shop_continue_button)), (0,D_next_project_next_practice_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_0__.default)(_jsxDEV3, "href", "/shop/5"), (0,D_next_project_next_practice_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_0__.default)(_jsxDEV3, "children", "Product details"), _jsxDEV3), void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 27,
          columnNumber: 7
        }, _this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 25,
        columnNumber: 5
      }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("style", {
        children: "\n    .blog_single_blog__122se {\n      width: 223px;\n      display: inline-block;\n      border: 1px solid #ddd;\n      padding: 10px;\n      margin: 5px;\n      border-radius: 5px;\n      line-height: 25px;\n    }\n    .blog_buttonArea__2ThKv a {\n      margin: 1px 5px;\n    }\n    \n    "
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 31,
        columnNumber: 3
      }, _this)]
    }, "{product.id}", true, {
      fileName: _jsxFileName,
      lineNumber: 18,
      columnNumber: 5
    }, _this);
  });
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(react__WEBPACK_IMPORTED_MODULE_2__.Fragment, {
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(_components_Layout__WEBPACK_IMPORTED_MODULE_4__.default, {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("h4", {
        className: (_styles_blog_module_css__WEBPACK_IMPORTED_MODULE_7___default().title),
        children: " Hello form Shop page.. "
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 56,
        columnNumber: 13
      }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
        className: (_styles_blog_module_css__WEBPACK_IMPORTED_MODULE_7___default().container),
        children: productsComponent
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 57,
        columnNumber: 13
      }, _this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 55,
      columnNumber: 11
    }, _this)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 54,
    columnNumber: 9
  }, _this);
}; //============================================
//getServerSideProps
//============================================
// export async function getServerSideProps(){


_c = Shop;
var __N_SSP = true;
/* harmony default export */ __webpack_exports__["default"] = (Shop);

var _c;

$RefreshReg$(_c, "Shop");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.id);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }


/***/ })

});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vcGFnZXMvc2hvcC9pbmRleC5qcyJdLCJuYW1lcyI6WyJTaG9wIiwicHJvcHMiLCJwcm9kdWN0c0NvbXBvbmVudCIsImRhdGEiLCJwcm9kdWN0cyIsInJhbmRvbV9wcm9kdWN0cyIsIm1hcCIsInByb2R1Y3QiLCJpbmRleCIsImJsb2dTdHlsZXMiLCJuYW1lIiwicGhvdG8iLCJoZWxsbyIsInByb2R1Y3REZXRhaWxzQnV0dG9uIiwic3R5bGVzIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQSxJQUFNQSxJQUFJLEdBQUcsU0FBUEEsSUFBTyxDQUFDQyxLQUFELEVBQVc7QUFBQTs7QUFFeEI7QUFDQTtBQUNBO0FBQ0E7QUFFQyxNQUFNQyxpQkFBaUIsNEJBQ3BCRCxLQUFLLENBQUNFLElBQU4sQ0FBV0MsUUFBWCxDQUFvQkMsZUFEQSwwREFDcEIsc0JBQXFDQyxHQUFyQyxDQUF5QyxVQUFDQyxPQUFELEVBQVNDLEtBQVQ7QUFBQTs7QUFBQSx3QkFDekM7QUFBd0IsZUFBUyxFQUFLQyw0RUFBdEM7QUFBQSw4QkFDQTtBQUFJLGlCQUFTLEVBQUtBLDJFQUFsQjtBQUFBLGtCQUNHRixPQUFPLENBQUNHO0FBRFg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURBLGVBS0EsOERBQUMsbURBQUQ7QUFBTyxXQUFHLEVBQUcsVUFBUUgsT0FBTyxDQUFDSSxLQUE3QjtBQUFvQyxhQUFLLEVBQUUsR0FBM0M7QUFBZ0QsY0FBTSxFQUFFO0FBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFMQSxlQU9BO0FBQUssaUJBQVMsRUFBRUYsMkVBQWhCO0FBQUEsZ0NBQ0U7QUFBRyxtQkFBUyxFQUFFQSwwRUFBZDtBQUFvQyxpQkFBTyxFQUFFO0FBQUEsbUJBQUlHLEtBQUssRUFBVDtBQUFBLFdBQTdDO0FBQTJELGNBQUksRUFBQztBQUFoRSw4SkFBc0ZILHFGQUF0RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQURGLGVBRUU7QUFBRyxtQkFBUyxFQUFFQSxxRkFBK0JJO0FBQTdDLDhKQUE0REoscUZBQTVELGlKQUFtRyxTQUFuRztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVBBLGVBYUY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFiRTtBQUFBLE9BQVMsY0FBVDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRHlDO0FBQUEsR0FBekMsQ0FESDtBQXFDRyxzQkFDSSw4REFBQywyQ0FBRDtBQUFBLDJCQUNFLDhEQUFDLHVEQUFEO0FBQUEsOEJBQ0U7QUFBSSxpQkFBUyxFQUFLSyxzRUFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFERixlQUVFO0FBQUssaUJBQVMsRUFBS0EsMEVBQW5CO0FBQUEsa0JBQ0daO0FBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FESjtBQVVILENBdERELEMsQ0F3REE7QUFDQTtBQUNBO0FBQ0E7OztLQTNETUYsSTs7QUFxRU4sK0RBQWVBLElBQWYiLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvc2hvcC41OTNkZjBhNzg5NjczMzBkMjZkYi5ob3QtdXBkYXRlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IEZyYWdtZW50IH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBzdHlsZXMgZnJvbSBcIi4uLy4uL3N0eWxlcy9ibG9nLm1vZHVsZS5jc3NcIjtcclxuaW1wb3J0IFNpbmdsZVByb2R1Y3QgZnJvbSAnLi4vLi4vY29tcG9uZW50cy9TaW5nbGVQcm9kdWN0J1xyXG5pbXBvcnQgTGF5b3V0IGZyb20gJy4uLy4uL2NvbXBvbmVudHMvTGF5b3V0J1xyXG5pbXBvcnQgYmxvZ1N0eWxlcyBmcm9tIFwiLi4vLi4vc3R5bGVzL2Jsb2cubW9kdWxlLmNzc1wiO1xyXG5pbXBvcnQgSW1hZ2UgZnJvbSAnbmV4dC9pbWFnZSc7XHJcbmltcG9ydCBMaW5rIGZyb20gJ25leHQvbGluayc7XHJcblxyXG5jb25zdCBTaG9wID0gKHByb3BzKSA9PiB7XHJcblxyXG4vLyBjb25zdCBoZWxsbyA9IGZ1bmN0aW9uKGUpe1xyXG4vLyAgIGUucHJldmVudERlZmF1bHQoKTtcclxuLy8gICBhbGVydCgnaGVsbG8uLi4nKTtcclxuLy8gfVxyXG5cclxuIGNvbnN0IHByb2R1Y3RzQ29tcG9uZW50ID0gKFxyXG4gICAgcHJvcHMuZGF0YS5wcm9kdWN0cy5yYW5kb21fcHJvZHVjdHM/Lm1hcCgocHJvZHVjdCxpbmRleCk9PlxyXG4gICAgPGRpdiBrZXk9XCJ7cHJvZHVjdC5pZH1cIiBjbGFzc05hbWUgPSB7IGJsb2dTdHlsZXMuc2luZ2xlX2Jsb2cgfT5cclxuICAgIDxoNCBjbGFzc05hbWUgPSB7IGJsb2dTdHlsZXMuYmxvZ190aXRsZSB9PlxyXG4gICAgICB7cHJvZHVjdC5uYW1lfVxyXG4gICAgPC9oND5cclxuICBcclxuICAgIDxJbWFnZSBzcmM9eyBcImh0dHA6XCIrcHJvZHVjdC5waG90b30gd2lkdGg9ezU1MH0gaGVpZ2h0PXszNTB9Lz5cclxuXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT17YmxvZ1N0eWxlcy5idXR0b25BcmVhfT5cclxuICAgICAgPGEgY2xhc3NOYW1lPXtibG9nU3R5bGVzLmFkZFRvQ2FydH0gb25DbGljaz17KCk9PmhlbGxvKCkgfSBocmVmPVwiL3Nob3AvNVwiIGNsYXNzTmFtZSA9e2Jsb2dTdHlsZXMuc2hvcF9jb250aW51ZV9idXR0b259PkFkZCB0byBjYXJ0PC9hPlxyXG4gICAgICA8YSBjbGFzc05hbWU9e2Jsb2dTdHlsZXMucHJvZHVjdERldGFpbHNCdXR0b259ICBjbGFzc05hbWUgPXtibG9nU3R5bGVzLnNob3BfY29udGludWVfYnV0dG9uIH0gaHJlZj1cIi9zaG9wLzVcIj5cclxuICAgICAgICBQcm9kdWN0IGRldGFpbHNcclxuICAgICAgPC9hPlxyXG4gICAgPC9kaXY+IFxyXG4gIDxzdHlsZT5cclxuICAgIHtgXHJcbiAgICAuYmxvZ19zaW5nbGVfYmxvZ19fMTIyc2Uge1xyXG4gICAgICB3aWR0aDogMjIzcHg7XHJcbiAgICAgIGRpc3BsYXk6IGlubGluZS1ibG9jaztcclxuICAgICAgYm9yZGVyOiAxcHggc29saWQgI2RkZDtcclxuICAgICAgcGFkZGluZzogMTBweDtcclxuICAgICAgbWFyZ2luOiA1cHg7XHJcbiAgICAgIGJvcmRlci1yYWRpdXM6IDVweDtcclxuICAgICAgbGluZS1oZWlnaHQ6IDI1cHg7XHJcbiAgICB9XHJcbiAgICAuYmxvZ19idXR0b25BcmVhX18yVGhLdiBhIHtcclxuICAgICAgbWFyZ2luOiAxcHggNXB4O1xyXG4gICAgfVxyXG4gICAgXHJcbiAgICBgfVxyXG4gIDwvc3R5bGU+XHJcbjwvZGl2PlxyXG4pKTtcclxuXHJcblxyXG5cclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPEZyYWdtZW50PlxyXG4gICAgICAgICAgPExheW91dD5cclxuICAgICAgICAgICAgPGg0IGNsYXNzTmFtZSA9IHsgc3R5bGVzLnRpdGxlIH0gPiBIZWxsbyBmb3JtIFNob3AgcGFnZS4uIDwvaDQ+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lID0geyBzdHlsZXMuY29udGFpbmVyIH0+ICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgIHtwcm9kdWN0c0NvbXBvbmVudH0gICAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIDwvZGl2PiBcclxuICAgICAgICAgIDwvTGF5b3V0PlxyXG4gICAgICAgIDwvRnJhZ21lbnQgPlxyXG4gICAgKTtcclxufTtcclxuXHJcbi8vPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuLy9nZXRTZXJ2ZXJTaWRlUHJvcHNcclxuLy89PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG4vLyBleHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0U2VydmVyU2lkZVByb3BzKCl7XHJcbiAgZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFNlcnZlclNpZGVQcm9wcygpe1xyXG4gIGNvbnN0IHJlcyA9IGF3YWl0IGZldGNoKCdodHRwczovL2RlbW9zdG9yZS51cGFyem9uLmNvbS9hcGkvdXBhcnpvbndlYi9nZXRfaG9tZV9wcm9kdWN0cycpO1xyXG4gIGNvbnN0IGRhdGEgPSBhd2FpdCByZXMuanNvbigpO1xyXG4gIHJldHVybiB7XHJcbiAgICBwcm9wczp7IGRhdGF9ICBcclxuICB9XHJcbn1cclxuXHJcblxyXG5leHBvcnQgZGVmYXVsdCBTaG9wOyJdLCJzb3VyY2VSb290IjoiIn0=