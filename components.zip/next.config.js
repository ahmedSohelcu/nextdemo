module.exports = {
  images:{
    domains:['demostore.uparzon.com']
  }
}